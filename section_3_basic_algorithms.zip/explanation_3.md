Created a merge sort then alternating the numbers and adding to strings to get the output.

O(nlogn) since we're using merge sort. Linear O(n) for space complexity since we're creating lists.
