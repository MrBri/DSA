Starting with an initial estimate then looping until there's no change. The Babylonian method.

Space complexity is O(log n) since it's roughly proportional to the binary digits of the input. Constant space complexity.

