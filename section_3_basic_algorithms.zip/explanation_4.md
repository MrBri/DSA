Creating three pointers and rearranging two of them leaving the third sorted.

Linear O(n) time complexity. Constant O(1) space complexity.
