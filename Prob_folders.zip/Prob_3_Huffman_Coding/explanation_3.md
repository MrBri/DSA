Took me a bit to even figure out what we were talking about here. Learned about heaps and decided to using the heapq which basically adds heap methods to a list. Also using defaultdict since you can add a bit of static typing. 

Space complexity is O(k) for the tree and O(n) for the decoded text. Time complexity in this cause would be O(n log k)
