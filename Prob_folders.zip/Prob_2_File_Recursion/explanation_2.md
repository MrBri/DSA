Using recursion and adding to (extend) the list each time. Using scandir which indicates if its a directory or file and even the metadata.

Linear space O(n) or I guess you could say O(h) with h being how many folders deep there are or height of the call stack. Assuming constant time using the built in functions since I'm not finding info on time efficiency.  
