Using a temporary Set for Union and a Dictionary for Intersection then transformed back to a Linked List.

Space can say is Linear O(n). Time since we're iterating multiple times but still Linear O(n).
