Using a linked list. Verbiage was a bit weird for using using previous but still the same concept as next.

Space complexity is linear O(n). Time the same as a Linked List, O(n) to search and access, O(1) to insert and delete.
