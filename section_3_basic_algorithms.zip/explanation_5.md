Storing the child as a hash table, could also use an array/list.

Searching is O(m) time complexity with m being the length of the word to search. Space complexity is determined by the number of characters in the alphabet and worst case scenario of O(nm) where n is the number of keys and m the length of the keys.
