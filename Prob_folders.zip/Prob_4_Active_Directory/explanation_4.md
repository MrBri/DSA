Using recursion to go through each group and check the users. 

Space is the height of the call stack O(h). Time would be constant O(1).
