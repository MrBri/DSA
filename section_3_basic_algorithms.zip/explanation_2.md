Like binary search but also checking if the left or right sides are sorted.

O(log n) time complexity. Constant space complexity.
