Trie data structure using hash tables to store children instead of list/arrays.

O(m) time complexity for lookup and add with m being the number of path parts. Space complexity depends on the number of routes n and length routes m O(nm).
