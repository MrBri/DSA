Using the dictionary in Python which with newer version of Python preserves the order but doesn't allow queue style popping which OrderedDict does. 

Linear space O(n), constant time to set and get O(1).
