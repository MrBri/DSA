Set initial values for min and max in this case infinity and negative infinity so they can easily be overridden.

Time is linear O(n) since we go through the list. Constant O(1) complexity since we just use a couple variables.
